from flask import Flask, request
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.dialects.mysql import DECIMAL, INTEGER, ENUM

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://username:password@localhost/db_name'
db = SQLAlchemy(app)

class HistoriaClinica(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    fname = db.Column(db.String(30), nullable=False)
    lname = db.Column(db.String(30), nullable=False)
    dob = db.Column(db.Date, nullable=False)
    pob = db.Column(db.String(100), nullable=False)
    sex = db.Column(ENUM('M', 'F', 'O'), nullable=False)
    occupation = db.Column(db.String(100), nullable=False)
    address = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(100), nullable=False)
    guardian = db.Column(db.String(100), nullable=False)
    mconsulta = db.Column(db.String(100), nullable=False)
    eactual = db.Column(db.String(100), nullable=False)
    apersonales = db.Column(db.String(100), nullable=False)
    afamiliares = db.Column(db.String(100), nullable=False)
    agineco = db.Column(db.String(100), nullable=False)
    peso = db.Column(DECIMAL(5,2), nullable=False)
    ta_sistole = db.Column(INTEGER(unsigned=True), nullable=False)
    ta_diastole = db.Column(INTEGER(unsigned=True), nullable=False)
    fc = db.Column(INTEGER(unsigned=True), nullable=False)
    fr = db.Column(INTEGER(unsigned=True), nullable=False)
    temp = db.Column(DECIMAL(3,1), nullable=False)
    sao2 = db.Column(DECIMAL(4,1), nullable=False)
    rsistemas = db.Column(db.String(200), nullable=False)
    efisico = db.Column(db.String(200), nullable=False)
    idiagnostica = db.Column(db.String(100), nullable=False)
    pmanejo = db.Column(db.String(200), nullable=False)
    omedicas = db.Column(db.String(200), nullable=False)
    salarma = db.Column(db.String(200), nullable=False)
    control = db.Column(db.String(100), nullable=False)

@app.route('/submit_patient', methods=['POST'])
def submit_patient():
    historia = HistoriaClinica()
    historia.fname = request.form.get('fname')
    historia.lname = request.form.get('lname')
    historia.dob = datetime.strptime(request.form.get('dob'), '%Y-%m-%d').date()  # Convierte la cadena a un objeto date
    historia.pob = request.form.get('pob')
    historia.sex = request.form.get('sex')
    historia.occupation = request.form.get('occupation')
    historia.address = request.form.get('address')
    historia.phone = request.form.get('phone')
    historia.guardian = request.form.get('guardian')
    historia.mconsulta = request.form.get('mconsulta')
    historia.eactual = request.form.get('eactual')
    historia.apersonales = request.form.get('apersonales')
    historia.afamiliares = request.form.get('afamiliares')
    historia.agineco = request.form.get('agineco')
    historia.ta_sistole = int(request.form.get('ta_sistole'))  
    historia.ta_diastole = int(request.form.get('ta_diastole'))
    historia.peso = Decimal(request.form.get('peso'))
    historia.fc = int(request.form.get('fc'))  
    historia.fr = int(request.form.get('fr'))  
    historia.temp = Decimal(request.form.get('temp'))
    historia.sao2 = Decimal(request.form.get('sao2'))
    historia.rsistemas = request.form.get('rsistemas')
    historia.efisico = request.form.get('efisico')
    historia.idiagnostica = request.form.get('idiagnostica')
    historia.pmanejo = request.form.get('pmanejo')
    historia.omedicas = request.form.get('omedicas')
    historia.salarma = request.form.get('salarma')
    historia.control = request.form.get('control')

    db.session.add(historia)
    db.session.commit()

    return 'Historia Clínica registrada exitosamente'

if __name__ == '__main__':
    db.create_all()  # crea las tablas en la base de datos
    app.run(debug=True)

