from django.urls import path
from . import views

urlpatterns = [
    path('', views.submit_patient, name='root'),
    path('submit_patient/', views.submit_patient, name='submit_patient'),
]

