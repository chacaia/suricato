from django import forms
from .models import HistoriaClinica

class HistoriaClinicaForm(forms.ModelForm):
    class Meta:
        model = HistoriaClinica
        fields = ['nombres', 'apellidos', 'dob', 'pob', 'sexo', 'ocupacion', 'direccion', 'telefono', 'familiar', 'mconsulta', 'eactual', 'apersonales', 'afamiliares', 'agineco', 'ta_sistole', 'ta_diastole', 'peso', 'fc', 'fr', 'temp', 'sao2', 'rsistemas', 'efisico', 'idiagnostica', 'pmanejo', 'omedicas', 'salarma', 'control']
        labels = {
            'nombres': 'Nombres',
            'apellidos': 'Apellidos',
            'dob': 'Fecha de nacimiento',
            'pob': 'Lugar de nacimiento',
            'sexo': 'Sexo',
            'ocupacion': 'Ocupación',
            'direccion': 'Dirección',
            'telefono': 'Teléfono',
            'familiar': 'Familiar',
            'mconsulta': 'Motivo de consulta',
            'eactual': 'Enfermedad actual',
            'apersonales': 'Antecedentes personales',
            'afamiliares': 'Antecedentes familiares',
            'agineco': 'Antecedentes Ginecoostétricos',
            'ta_sistole': 'TA sistólica',
            'ta_diastole': 'TA diastólica',
            'peso': 'Peso',
            'fc': 'FC',
            'fr': 'FR',
            'temp': 'Temperatura',
            'sao2': 'SaO2',
            'rsistemas': 'Revisión por sistemas',
            'efisico': 'Examen Físico',
            'idiagnostica': 'Impresión diagnóstica',
            'pmanejo': 'Plan de manejo',
            'omedicas': 'Órdenes médicas',
            'salarma': 'Signos de alarma',
            'control': 'Control',
        }
        
        widgets = {
            'dob': forms.DateInput(attrs={'type': 'date'}),
        }
