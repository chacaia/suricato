from django.core.exceptions import ValidationError
from django.db import models
import re
def validate_phone_number(value):
    if not re.match(r'^\+?[0-9]+$', value):
        raise ValidationError("El número de teléfono solo puede contener números y el signo +")

class HistoriaClinica(models.Model):
    nombres = models.CharField(max_length=32)
    apellidos = models.CharField(max_length=32)
    dob = models.DateField()
    pob = models.CharField(max_length=30)
    
    SEXO_CHOICES = [
        ('H', 'Hombre'),
        ('M', 'Mujer'),
        ('O', 'Otro'),
    ]

    sexo = models.CharField(
        max_length=1,
        choices=SEXO_CHOICES,
        default='M',
    )
    
    ocupacion = models.CharField(max_length=30)
    direccion = models.CharField(max_length=30)
    telefono = models.CharField(max_length=15, validators=[validate_phone_number])
    familiar = models.CharField(max_length=40)
    mconsulta = models.TextField()
    eactual = models.TextField()
    apersonales = models.TextField()
    afamiliares = models.TextField()
    agineco = models.TextField()
    peso = models.DecimalField(max_digits=3, decimal_places=1)  
    ta_sistole = models.IntegerField() 
    ta_diastole = models.IntegerField()
    def get_tension_arterial(self):
     return f"{self.ta_sistole}/{self.ta_diastole}"
    fc = models.IntegerField()  
    fr = models.IntegerField()  
    temp = models.DecimalField(max_digits=2, decimal_places=1)
    sao2 = models.DecimalField(max_digits=2, decimal_places=0)  
    rsistemas = models.TextField()
    efisico = models.TextField()
    idiagnostica = models.TextField()
    pmanejo = models.TextField()
    omedicas = models.TextField()
    salarma = models.TextField()
    control = models.TextField()

