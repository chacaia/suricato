from django.shortcuts import render, redirect
from .models import HistoriaClinica
from .forms import HistoriaClinicaForm
from decimal import Decimal
from datetime import datetime

def submit_patient(request):
    if request.method == 'POST':
        form = HistoriaClinicaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('submit_patient')
        else:
            form = HistoriaClinicaForm()             
            historia = HistoriaClinica()
            historia.fname = request.POST.get('fname')
            historia.lname = request.POST.get('lname')
            historia.dob = datetime.strptime(request.POST.get('dob'), '%Y-%m-%d').date() 
            historia.pob = request.POST.get('pob')
            historia.sex = request.POST.get('sex')
            historia.occupation = request.POST.get('occupation')
            historia.address = request.POST.get('address')
            historia.phone = request.POST.get('phone')
            historia.guardian = request.POST.get('guardian')
            historia.mconsulta = request.POST.get('mconsulta')
            historia.eactual = request.POST.get('eactual')
            historia.apersonales = request.POST.get('apersonales')
            historia.eactual = request.POST.get('eactual')
            historia.apersonales = request.POST.get('apersonales')
            historia.afamiliares = request.POST.get('afamiliares')
            historia.agineco = request.POST.get('agineco')
            historia.ta_sistole = int(request.POST.get('ta_sistole'))  # Convierte la cadena a un entero
            historia.ta_diastole = int(request.POST.get('ta_diastole'))  # Convierte la cadena a un entero
            historia.peso = Decimal(request.POST.get('peso'))  # Convierte la cadena a un Decimal
            historia.fc = int(request.POST.get('fc'))  # Convierte la cadena a un entero
            historia.fr = int(request.POST.get('fr'))  # Convierte la cadena a un entero
            historia.temp = Decimal(request.POST.get('temp'))  # Convierte la cadena a un Decimal
            historia.sao2 = Decimal(request.POST.get('sao2'))  # Convierte la cadena a un Decimal
            historia.rsistemas = request.POST.get('rsistemas')
            historia.efisico = request.POST.get('efisico')
            historia.idiagnostica = request.POST.get('idiagnostica')
            historia.pmanejo = request.POST.get('pmanejo')
            historia.omedicas = request.POST.get('omedicas')
            historia.salarma = request.POST.get('salarma')
            historia.control = request.POST.get('control')
            historia.save()
    else:
        form = HistoriaClinicaForm()    
    
    return render(request, 'index.html', {'form': form})
